package com.example.xpo.controller;

public class TurmaController {

}
