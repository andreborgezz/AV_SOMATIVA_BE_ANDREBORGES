package com.example.xpo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.xpo.entities.Autor;
import com.example.xpo.service.AutorService;

public class AutorController {
  private final AutorService autorService;

  @Autowired
  public AutorController(AutorService autorService) {
      this.autorService = autorService;
  }

  @PostMapping
  public Autor createProduct(@RequestBody Autor Autor) {
      return autorService.saveAutor(Autor);
  }

  @GetMapping("/{id}")
  public Autor getAutor(@PathVariable Long id) {
      return autorService.getAutorById(id);
  }

  @GetMapping
  public List<Autor> getAllAutors() {
      return AutorService.getAllAutor();
  }

  @DeleteMapping("/{id}")
  public void deleteAutor(@PathVariable Long id) {
      autorService.deleteAutor(id);

}}
