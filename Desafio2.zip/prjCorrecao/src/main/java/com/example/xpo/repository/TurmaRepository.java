package com.example.xpo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.xpo.entities.Turma;

public interface TurmaRepository extends JpaRepository<Turma,Long> {
}