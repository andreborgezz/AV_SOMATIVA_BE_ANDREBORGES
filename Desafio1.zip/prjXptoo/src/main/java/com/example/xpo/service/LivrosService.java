package com.example.xpo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.xpo.entities.Livros;
import com.example.xpo.repository.LivrosRepository;

public class LivrosService {
	 private final LivrosRepository livrosRepository;

	    @Autowired
	    public LivrosService(LivrosRepository livrosRepository) {
	        this.livrosRepository = livrosRepository;
	    }

	    public Livros saveLivros(Livros livros) {
	        return livrosRepository.save(livros);
	    }

	    public Livros getLivrosById(Long id) {
	        return livrosRepository.findById(id).orElse(null);
	    }

	    public List<Livros> getAllLivross() {
	        return livrosRepository.findAll();
	    }

	    public void deleteLivros(Long id) {
	        livrosRepository.deleteById(id);
	    }

	    public List<Livros> buscarPorTitulo(String titulo){
	    	return livrosRepository.buscarPorTitulo(titulo);
	    }
	    public List<Livros> buscarPorAutor(String autor){
	    	return livrosRepository.findByAutor(autor);
	    }
	    public List<Livros> buscarPorNome(String nome){
	    	return livrosRepository.findByNome(nome);
	    }
	    
	    
}
