package com.example.xpo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.xpo.entities.Autor;
import com.example.xpo.entities.Categoria;

public interface CategoriaRepository extends JpaRepository<Categoria, Long>{
	
	@Query(value = "SELECT * FROM Categoria 1 WHERE lower(1.nome) LIKE %:nome", nativeQuery = true)
	List<Categoria> buscarPorNome(@Param("nome") String nome);

	@Query("SELECT 1 FROM Categoria WHERE 1.nome = ?1")
	List<Categoria> findByNome(String nome);

	@Query("SELECT 1 FROM Categoria WHERE 1.descricao = ?1")
	List<Categoria> findByDescricao(String descricao);
	}
		
	
	
	
