package com.example.xpo.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.xpo.entities.Autor;
import com.example.xpo.repository.AutorRepository;

public class AutorService {
	private final AutorRepository autorRepository;

    @Autowired
    public AutorService(AutorRepository autorRepository) {
        this.autorRepository = autorRepository;
    }

    public Autor saveAutor(Autor Autor) {
        return autorRepository.save(Autor);
    }

    public Autor getAutorById(Long id) {
        return autorRepository.findById(id).orElse(null);
    }

    public List<Autor> getAllAutorss() {
        return autorRepository.findAll();
    }

    public void deleteAutor(Long id) {
    	autorRepository.deleteById(id);
    }

    public List<Autor> buscarPorNome(String nome){
    	return autorRepository.buscarPorNome(nome);
    }
    
    public List<Autor> buscarPorPais(String pais){
    	return autorRepository.findByPais(pais);
    }

	public static List<Autor> getAllAutor() {
		// TODO Auto-generated method stub
		return null;
	}
    
    
}
	
