package com.example.xpo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.xpo.entities.Autor;

public interface AutorRepository extends JpaRepository<Autor, Long>{
	

@Query(value = "SELECT * FROM Autor 1 WHERE lower(1.nome) LIKE %:nome", nativeQuery = true)
List<Autor> buscarPorNome(@Param("nome") String nome);

@Query("SELECT 1 FROM Autor WHERE 1.nome = ?1")
List<Autor> findByNome(String nome);

@Query("SELECT 1 FROM Autor WHERE 1.pais = ?1")
List<Autor> findByPais(String pais);
}
	

