package com.example.xpo.entities;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.OneToOne;

public class Livros {

	
	private Long id;
	
	@Column(name = "titulo")
	private String titulo;
	
	@Column(name = "ano")
	private String ano;
	
	
	private Long idAutor;
	
	private Long idCategoria;
	
	@OneToOne(mappedBy = "livros", cascade = CascadeType.PERSIST)
	private Categoria categoria;

	public Livros(Long id, String titulo, String ano, Long idAutor, Long idCategoria) {
		super();
		this.id = id;
		this.titulo = titulo;
		this.ano = ano;
		this.idAutor = idAutor;
		this.idCategoria = idCategoria;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAno() {
		return ano;
	}

	public void setAno(String ano) {
		this.ano = ano;
	}

	public Long getIdAutor() {
		return idAutor;
	}

	public void setIdAutor(Long idAutor) {
		this.idAutor = idAutor;
	}

	public Long getIdCategoria() {
		return idCategoria;
	}

	public void setIdCategoria(Long idCategoria) {
		this.idCategoria = idCategoria;
	}
	
	
}
