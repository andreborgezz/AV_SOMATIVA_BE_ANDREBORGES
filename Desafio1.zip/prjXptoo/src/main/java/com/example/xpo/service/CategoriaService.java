package com.example.xpo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.xpo.entities.Categoria;
import com.example.xpo.repository.CategoriaRepository;
import com.example.xpo.repository.CategoriaRepository;

public class CategoriaService {
   private final CategoriaRepository categoriaRepository;
   
   @Autowired
   public CategoriaService(CategoriaRepository categoriaRepository) {
       this.categoriaRepository = categoriaRepository;
   }

   public Categoria saveCategoria(Categoria categoria) {
       return categoriaRepository.save(categoria);
   }

   public Categoria getCategoriaById(Long id) {
       return categoriaRepository.findById(id).orElse(null);
   }

   public List<Categoria> getAllCategoria() {
       return categoriaRepository.findAll();
   }

   public void deleteCategoria(Long id) {
       categoriaRepository.deleteById(id);
   }

   public List<Categoria> buscarPorNome(String nome){
   	return categoriaRepository.buscarPorNome(nome);
   }
   public List<Categoria> buscarPorCategoria(String descricao){
   	return categoriaRepository.findByDescricao(descricao);
   }

}
