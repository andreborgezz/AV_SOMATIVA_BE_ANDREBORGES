package com.example.xpo.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;

import com.example.xpo.entities.Turma;
import com.example.xpo.repository.TurmaRepository;

public class TurmaService {

    private final TurmaRepository turmaRepository;
    
    @Autowired
    public TurmaService(TurmaRepository turmaRepository) {
        this.turmaRepository = turmaRepository;
    }

    public List<Turma> getAllTurma() {
        return turmaRepository.findAll();
    }

    public Turma getTurmaById(Long id) {
        Optional<Turma> turma = turmaRepository.findById(id);
        return turma.orElse(null);
    }

    public Turma saveTurma(Turma turma) {
        return turmaRepository.save(turma);
    }

    public Turma updateTurma(Long id, Turma updateTurma) {
        Optional<Turma> existTurma = turmaRepository.findById(id);
        if (existTurma.isPresent()) {
            updateTurma.setId(id);
            return turmaRepository.save(updateTurma);
        }
        return null;
    }

    public boolean deleteTurma(Long id) {
        Optional<Turma> existTurma = turmaRepository.findById(id);
        if (existTurma.isPresent()) {
            turmaRepository.deleteById(id);
            return true;
        }
        return false;
    }
}

