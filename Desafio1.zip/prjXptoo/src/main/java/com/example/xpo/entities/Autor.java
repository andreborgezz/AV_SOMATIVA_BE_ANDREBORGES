package com.example.xpo.entities;

import jakarta.persistence.Column;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

public class Autor {

	private Long id;
	
	@Column(name = "Nome")
	private String Nome;
	
	@Column(name = "País")
	private String País;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_livros", nullable = false)
	private Livros livro;
	
	
	
	
	public Autor(Long id, String nome, String país) {
		super();
		this.id = id;
		Nome = nome;
		País = país;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public String getPaís() {
		return País;
	}

	public void setPaís(String país) {
		País = país;
	}
	
	
	
	
}
