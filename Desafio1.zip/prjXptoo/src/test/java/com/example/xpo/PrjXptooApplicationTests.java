package com.example.xpo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrjXptooApplicationTests {

	@Test
	void contextLoads() {
	}

}
