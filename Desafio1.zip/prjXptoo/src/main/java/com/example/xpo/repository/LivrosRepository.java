package com.example.xpo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.xpo.entities.Livros;

public interface LivrosRepository extends JpaRepository<Livros, Long>{	
	
	@Query(value = "SELECT * FROM Livro 1 WHERE lower(1.titulo) LIKE %:titulo", nativeQuery = true)
	List<Livros> buscarPorTitulo(@Param("titulo") String titulo);

	@Query("SELECT 1 FROM Livro WHERE 1.autor = ?1")
	List<Livros> findByAutor(String autor);

	@Query("SELECT 1 FROM Livro WHERE 1.nome = ?1")
	List<Livros> findByNome(String nome);

	@Query("SELECT 1 FROM Livro WHERE 1.editora = ?1")
	List<Livros> findByEditora(String editora);

	@Query("SELECT 1 FROM Livro WHERE 1.isbn = ?1")
	List<Livros> findByIsbn(String isbn);
	}

