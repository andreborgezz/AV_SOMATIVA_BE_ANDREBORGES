package com.example.xpo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.example.xpo.entities.Aluno;

public interface AlunoRepository extends JpaRepository<Aluno, Long> {
	
	//Query Methods
	List<Aluno> findByCidade(String cidade);
	Aluno findByRa(String ra);
	List<Aluno> findByAlunoPorNomeERenda(String nome, Double renda);
	List<Aluno> findByNome(String nome);
	List<Aluno> findByCidadeAndRenda(String cidade, Double renda);
	List<Aluno> findByNomeLike(String nomeCompleto);
	List<Aluno> findByTurmaId(Long turmaId);

}